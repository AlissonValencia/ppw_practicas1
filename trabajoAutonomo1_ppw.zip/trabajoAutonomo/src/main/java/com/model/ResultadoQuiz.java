package com.model;

public class ResultadoQuiz {
    private int puntaje;
    private int totalPreguntas;
    private String calificacion;
    
    public ResultadoQuiz() {}
    
    public ResultadoQuiz(int puntaje, int totalPreguntas) {
        this.puntaje = puntaje;
        this.totalPreguntas = totalPreguntas;
        calcularCalificacion();
    }
    
    private void calcularCalificacion() {
        double porcentaje = (double) puntaje / totalPreguntas * 100;
        if (porcentaje >= 90) {
            calificacion = "A (Excelente)";
        } else if (porcentaje >= 80) {
            calificacion = "B (Muy Bueno)";
        } else if (porcentaje >= 70) {
            calificacion = "C (Bueno)";
        } else if (porcentaje >= 60) {
            calificacion = "D (Regular)";
        } else {
            calificacion = "F (Necesitas estudiar más)";
        }
    }
    
    // Getters y Setters
    public int getPuntaje() { return puntaje; }
    public void setPuntaje(int puntaje) { 
        this.puntaje = puntaje; 
        calcularCalificacion();
    }
    
    public int getTotalPreguntas() { return totalPreguntas; }
    public void setTotalPreguntas(int totalPreguntas) { 
        this.totalPreguntas = totalPreguntas; 
        calcularCalificacion();
    }
    
    public String getCalificacion() { return calificacion; }
    public void setCalificacion(String calificacion) { this.calificacion = calificacion; }
}