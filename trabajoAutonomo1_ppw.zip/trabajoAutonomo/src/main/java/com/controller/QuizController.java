package com.controller;

import javax.servlet.*;
import javax.servlet.http.*;

import com.model.ResultadoQuiz;

import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/quiz")
public class QuizController extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Respuestas correctas actualizadas con 10 preguntas
        String[] respuestasCorrectas = {
            "L.J. Smith",           // q1
            "Paul Wesley",          // q2  
            "8",                    // q3
            "Damon Salvatore",      // q4
            "Covington",            // q5
            "Nina Dobrev",          // q6
            "Temporada 4",          // q7
            "Jeremy Gilbert",       // q8
            "Bonnie Bennett",       // q9
            "Elijah Mikaelson"      // q10
        };
        
        // Obtener respuestas del usuario
        String[] respuestasUsuario = {
            request.getParameter("q1"),
            request.getParameter("q2"),
            request.getParameter("q3"),
            request.getParameter("q4"),
            request.getParameter("q5"),
            request.getParameter("q6"),
            request.getParameter("q7"),
            request.getParameter("q8"),
            request.getParameter("q9"),
            request.getParameter("q10")
        };
        
        // Calcular puntaje
        int puntaje = 0;
        for (int i = 0; i < respuestasCorrectas.length; i++) {
            if (respuestasCorrectas[i].equals(respuestasUsuario[i])) {
                puntaje++;
            }
        }
        
        // Crear resultado
        ResultadoQuiz resultado = new ResultadoQuiz(puntaje, respuestasCorrectas.length);
        
        // Pasar resultado al JSP
        request.setAttribute("resultadoQuiz", resultado);
        request.setAttribute("respuestasUsuario", respuestasUsuario);
        request.setAttribute("respuestasCorrectas", respuestasCorrectas);
        
        // Redirigir a la página de resultados
        RequestDispatcher dispatcher = request.getRequestDispatcher("resultado.jsp");
        dispatcher.forward(request, response);
    }
}